Changelog
=========

1.0.0 - First official release, supports export to Excel with graphs, ToC and worksheet per vulnerability
