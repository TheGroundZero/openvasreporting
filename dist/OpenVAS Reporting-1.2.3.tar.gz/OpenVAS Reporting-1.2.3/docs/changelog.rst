Changelog
=========

1.2.3  - Implement https://github.com/cr0hn/openvas_to_report/pull/12

1.2.2  - Fix bug where port info was not correctly extracted.

1.2.1  - Fix bug where affected hosts were added on wrong row in Excel export.

1.2.0  - Functional export to Word document (.docx). Includes some formatting. TODO: graphs

1.1.0a - Support for exporting to Word document (.docx). Limited formatting, needs more testing

1.0.1a - Small updates, preparing for export to other formats

1.0.0  - First official release, supports export to Excel with graphs, ToC and worksheet per vulnerability
