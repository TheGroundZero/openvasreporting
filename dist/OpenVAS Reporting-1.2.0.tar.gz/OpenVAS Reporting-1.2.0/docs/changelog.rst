Changelog
=========

1.1.0-alpha - Support for exporting to Word document (.docx). Limited formatting, needs more testing

1.0.1-alpha - Small updates, preparing for export to other formats

1.0.0 - First official release, supports export to Excel with graphs, ToC and worksheet per vulnerability
